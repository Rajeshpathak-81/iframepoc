window.addEventListener('load', function() {
		var idiv = document.createElement("div");
		idiv.setAttribute("id","diviframe")
		idiv.setAttribute("style", "right:0;position:fixed;bottom:40px;display:none;");
	    document.getElementsByTagName('body')[0].appendChild(idiv);
        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", "index-custom2.html");
		ifrm.setAttribute("id", "ifrm");
        ifrm.style.width = "400px";ifrm.style.height = "530px";
		ifrm.setAttribute("frameborder","0");		
		idiv.appendChild(ifrm);
		
		
		var iprof = document.createElement("div");
		iprof.setAttribute("id","profile_div");
		iprof.setAttribute("class","profile_div");
		iprof.setAttribute("style", "right:0;position:fixed;bottom:0;");
		iprof.setAttribute("onclick","x=document.getElementById('diviframe');x.style.display === 'none' ? x.style.display='block':x.style.display='none'");
	    document.body.appendChild(iprof);
		
		var iimage = document.createElement("img");
        iimage.setAttribute("src", "./static/img/botAvatar.png");
		iimage.setAttribute("class","imgProfile");
		iprof.appendChild(iimage);
		
});